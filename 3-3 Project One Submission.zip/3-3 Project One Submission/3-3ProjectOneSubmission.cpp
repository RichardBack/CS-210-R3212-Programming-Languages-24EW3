#include <iostream>
#include <iomanip>

// Create clock class to calculate time in 24 hour format
class Clock {
private:
    int hours, minutes, seconds;

public:
    // Use constructor to initialize time to 00:00:00
    Clock() : hours(0), minutes(0), seconds(0) {}

    // Initialize the time with given values for hours, minuts, seconds
    void setTime(int h, int m, int s) {  
        hours = (h >= 0 && h < 24) ? h : 0;
        minutes = (m >= 0 && m < 60) ? m : 0;
        seconds = (s >= 0 && s < 60) ? s : 0;
    }
    // Increase the value of hours, to support transition to the next day if required
    void addHour() {
        if (++hours == 24) hours = 0;  // include if statement
    }
    // Increse the value of minutes, to support transition to the next hour if required
    void addMinute() {
        if (++minutes == 60) {
            minutes = 0;
            addHour();
        }
    }
    // Increse the value of second, to support transition to the next minute if required
    void addSecond() {
        if (++seconds == 60) {
            seconds = 0;
            addMinute();
        }
    }

    void displayTime() const { //Display time in HH:MM:SS format
        std::cout << std::setw(2) << std::setfill('0') << hours << ":"
            << std::setw(2) << std::setfill('0') << minutes << ":"
            << std::setw(2) << std::setfill('0') << seconds << std::endl;
    }
};
// Display menu options for user selection
void displayMenu() {
    std::cout << "1. Add Hour\n"
        << "2. Add Minute\n"
        << "3. Add Second\n"
        << "4. Display Time\n"
        << "5. Exit\n"
        << "Enter choice: ";
}

int main() {
    Clock myClock;
    int choice, h, m, s;

    // Get initial time from the user
    std::cout << "Set initial time (HH MM SS): ";
    std::cin >> h >> m >> s;
    myClock.setTime(h, m, s);

    // Program loop based on cases
    do {
        displayMenu(); // Display menu to user
        std::cin >> choice;

        switch (choice) {  // Display menu options
        case 1: myClock.addHour(); break;
        case 2: myClock.addMinute(); break;
        case 3: myClock.addSecond(); break;
        case 4: myClock.displayTime(); break;
        case 5: break;
        default: std::cout << "Invalid choice, please try again.\n";
        }
    } while (choice != 5);  // Establish condtional while loop to handle 
                             // case scenarios and to exit the loop

    return 0;  // End program
}